﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        String operation = "";
        Double res = 0;
        bool isOperPressed = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void button_click(object sender, EventArgs e)
        {
            if((txt_Res.Text == "0") || (isOperPressed))
            {
                txt_Res.Clear();
            }

            isOperPressed = false;
            Button button = (Button)sender;
            if(button.Text == ".")
            {
                if(!txt_Res.Text.Contains("."))
                {
                    txt_Res.Text = txt_Res.Text + button.Text;
                }
            }else
            txt_Res.Text = txt_Res.Text + button.Text;
        }

        private void clear_click(object sender, EventArgs e)
        {
            txt_Res.Text = "0";
        }

        private void clearAll_click(object sender, EventArgs e)
        {
            txt_Res.Text = "0";
            res = 0;
            
        }



        private void equal_click(object sender, EventArgs e)
        {
            switch(operation)
            {
                case "+":
                    txt_Res.Text = (res + Double.Parse(txt_Res.Text)).ToString();
                    break;
                case "-":
                    txt_Res.Text = (res - Double.Parse(txt_Res.Text)).ToString();
                    break;
                case "*":
                    txt_Res.Text = (res * Double.Parse(txt_Res.Text)).ToString();
                    break;
                case "/":
                    txt_Res.Text = (res / Double.Parse(txt_Res.Text)).ToString();
                    break;
                default:
                    break;

            }
            res = Double.Parse(txt_Res.Text);
            lbl_1.Text = "";
        }

        private void operation_click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            if(res != 0)
            {
                buttonEqual.PerformClick();
                operation = button.Text;
                res = Double.Parse(txt_Res.Text);
                lbl_1.Text = res + " " + operation;
                isOperPressed = true;

            }
            else
            {
                operation = button.Text;
                res = Double.Parse(txt_Res.Text);
                lbl_1.Text = res + " " + operation;
                isOperPressed = true;
            }
        }
    }
}
